const htmlAccessor = {
    OBJECT_INFORMATION: document.getElementById('object_info')
};